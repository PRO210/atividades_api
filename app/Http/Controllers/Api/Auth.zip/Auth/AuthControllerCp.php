<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Traits\MessagesReponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{

  use MessagesReponses;

  public function __construct()
  {
    // $this->middleware('auth:sanctum')->only(['store', 'update']);
  }

  /**
   * Display a listing of the resource.
   */
  //
  public function login(Request $request)
  {
    if (Auth::attempt($request->only('email', 'password'))) {
      return $this->success('Authorized', 200, [
        'token' => $request->user()->createToken('user')->plainTextToken
      ]);
    }
    return $this->error('Not Authorized', 403);
  }

  /**
   * Show the form for creating a new resource.
   */
  public function logout(Request $request)
  {
    $request->user()->currentAccessToken()->delete();
    return $this->success('Token Revogado', 200);
  }

  /**
   * Store a newly created resource in storage.
   */
  public function store(Request $request)
  {
    //
  }

  /**
   * Display the specified resource.
   */
  public function show(string $id)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   */
  public function edit(string $id)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   */
  public function update(Request $request, string $id)
  {
    //
  }

  /**
   * Remove the specified resource from storage.
   */
  public function destroy(string $id)
  {
    //
  }
}
