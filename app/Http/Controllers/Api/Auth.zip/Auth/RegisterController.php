<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\RegisterService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Traits\MessagesReponses;
use Illuminate\Validation\Rule;

class RegisterController extends Controller
{

  use MessagesReponses;

  public function __construct(
    protected User $repository,
  ) {
  }

  public function store(Request $request)
  {
    // if (!auth()->user()->tokenCan('user-store')) {
    //   return $this->error('Unauthorized', 403);
    // }
    $userService = new RegisterService();
    $user = $userService->register($request);

    return new UserResource($user);
  }
  /**
   * Display the user's profile form.
   */
  public function edit($uuid)
  {
    $user = $this->repository::where('uuid', $uuid)->first();

    return new UserResource($user);
  }
  /**
   * Update the user's profile information.
   */
  public function update(Request $request)
  {
    $data = $request->all();
    $oldData = $request->all();

    // if ($request->password) {
    //   $data['password'] = bcrypt($request->password);
    // }
    $user = $this->repository::where('uuid', $request->uuid)->first();

    if (!$user) {
      return $this->error('Usuário não Encontrado', 404, $oldData);
    }

    $validator = Validator::make($data, [
      'name' => ['required', 'string', 'min:3', 'max:255'],
      'email' => [
        'required', 'string', 'email', 'max:255',
        Rule::unique('users')->ignore($user->id),
        'password' => Rule::requiredIf($request->password)

      ],
    ]);

    if ($validator->fails()) {
      return $this->error('Dados Invalidos', 422, $validator->errors(), $oldData);
    }

    $user->update($validator->validated());


    return new UserResource($user);
  }

  public function destroy(string $uuid)
  {
    $user = $this->repository::where('uuid', $uuid)->first();
    $user->delete();

    // return response()->json([], Response::HTTP_NO_CONTENT);
    return $this->success('Operação realizada com Sucesso!', 200);
  }
}
